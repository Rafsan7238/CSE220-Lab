public class StackOverflowException extends Exception{
    
//    public String toString(){
//        return "StackOverflowException";
//    }

}