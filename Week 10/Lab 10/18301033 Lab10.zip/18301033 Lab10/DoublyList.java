import java.util.*;

public class DoublyList{
    public DoublyNode head;
    
    
    /* First Constructor:
     * Creates a linked list using the values from the given array. head will refer
     * to the DoublyNode that contains the element from a[0]
     */ 
    public DoublyList(int [] a){
        head = new DoublyNode(0, null, null);
        DoublyNode tail = head;
        
        for(int i = 0; i<a.length; i++){
            DoublyNode mn = new DoublyNode(a[i], null, null);
            tail.next = mn;
            mn.prev=tail;
            tail=tail.next;
        }
        tail.next=head; // Making it circular
        head.prev=tail;
    }
    
    /* Second Constructor:
     * Sets the value of head. head will refer
     * to the given LinkedList
     */
    public DoublyList(DoublyNode h){
        head = h;
    }
    
    /* Counts the number of DoublyNodes in the list */
    public int countDoublyNode(){
        // TO DO
        
        System.out.println();
        
        int count=0;
            
        for(DoublyNode n=head.next; n!=head; n=n.next){
                count++;
            }
        
        return count; 
    }
    
    /* prints the elements in the list */
    public void forwardprint(){
        // TO DO 
        
        
        for(DoublyNode n=head.next; n!=head; n=n.next){
            System.out.print(n.element + " ");
        }
    }
    
    public void backwardprint(){
        // TO DO 
        
        System.out.println();
        
        for(DoublyNode n=head.prev; n!=head; n=n.prev){
            System.out.print(n.element + " ");
        }
    }
    
    
    // returns the reference of the DoublyNode at the given index. For invalid index return null.
    public DoublyNode nodeAt(int idx){
        // TO DO
        
        DoublyNode n=head.next;
        
        for(int i=0; i<idx && n!=head; i++){
            n=n.next;
        }
        
        if(idx>=0 && n!=head){
            return n;
        }
        
        return null; 
    }
    
    
    
    /* returns the index of the DoublyNode containing the given element.
     if the element does not exist in the List, return -1.
     */
    public int indexOf(int elem){
        // TO DO
        
        DoublyNode n=head.next;
        
        for(int i=0; n!=head; i++, n=n.next){
            if(n.element==elem){
                return i;
            }
        }
  
        return -1; 
    }
    
    
    
    /* inserts DoublyNode containing the given element at the given index
     * Check validity of index.
     */
    public void insert(int elem, int idx){
        // TO DO
        
        int j=countDoublyNode();
        DoublyNode n=nodeAt(idx);
        
        DoublyNode x=new DoublyNode(elem, null, null);
        
        if(idx>=0 && idx<j){
            x.next=n;
            x.prev=n.prev;
            x.prev.next=x;
            n.prev=x;
        } 
        
        else if(idx==j){
            x.next=head;
            x.prev=head.prev;
            x.prev.next=x;
            head.prev=x;
        }
        
        else{
            System.out.println("Invalid index!");
        }
    }
    
    
    
    /* removes DoublyNode at the given index. returns element of the removed node.
     * Check validity of index. return null if index is invalid.
     */
    public Object remove(int index){
        // TO DO
        
        System.out.println();
        
        int j=countDoublyNode();
        
        if(index>=0 &&  index<j){
            DoublyNode n=nodeAt(index);
            n.prev.next=n.next;
            n.next.prev=n.prev;
            
            return n.element;
        }
        
        return null; 
    }
    
    
    
}