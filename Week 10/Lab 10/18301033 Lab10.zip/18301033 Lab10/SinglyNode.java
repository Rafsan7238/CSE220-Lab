public class SinglyNode{
  public int element;
  public SinglyNode next;
  
  public SinglyNode(int e, SinglyNode n){
    element = e ;
    next = n;
    
  }
  
}