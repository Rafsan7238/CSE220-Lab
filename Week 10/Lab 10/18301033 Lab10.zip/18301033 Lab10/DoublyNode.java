public class DoublyNode{
  public int element;
  public DoublyNode next;
  public DoublyNode prev;
  
  public DoublyNode(int e, DoublyNode n, DoublyNode p){
    element =e ;
    next = n;
    prev =p;
    
  }
  
}