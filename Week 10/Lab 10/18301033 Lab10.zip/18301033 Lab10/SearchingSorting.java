public class SearchingSorting{
    
    public static int findMinInd(int[] a, int st){
        if(a.length-1==st){
            return st;
        }
        
        int minInd = findMinInd(a, st+1);
        if(a[st]<a[minInd]){
            minInd = st;
        }
        
        return minInd;
    }
    
    public static void selSortArray(int[] a, int i){
        if(i==a.length-1){
            return;
        }
        
        int minInd = findMinInd(a,i);
        int temp = a[i];
        a[i] = a[minInd];
        a[minInd] = temp;
        selSortArray(a, i+1);
    }
    
    public static void insertionSortArray(int[] a, int end){
        if(end<=1){
            return;
        }
        
        insertionSortArray(a, end-1);
        int key = a[end-1];
        int j = end-2;
        
        while(j>=0 && key<a[j]){
            a[j+1] = a[j];
            j--;
        }
        
        a[j+1]=key;
    }
    
    public static void swap(LinkedList x, int i, int j, int size){
        if(j==size-i){
            return;
        }
        
        SinglyNode a = x.nodeAt(j-1);
        SinglyNode b = a.next;
        
        if(a.element>b.element){
            int temp = a.element;
            a.element = b.element;
            b.element = temp;
        }
        
        swap(x, i, j+1, size);
    }
    
    public static void bubbleSortList(LinkedList n, int i, int size){
        if(i==size-1){
            return;
        }
        
        swap(n, i, 1, size);
        bubbleSortList(n, i+1, size);
    }
    
    public static SinglyNode findMinNode(LinkedList h, int i, int size){
        if(size-1==i){
            return h.nodeAt(i);
        }
        
        SinglyNode minNode = findMinNode(h, i+1, size);
        if(h.nodeAt(i).element<minNode.element){
            minNode = h.nodeAt(i);
        }
        
        return minNode;
    }
    
    public static void selSortList(LinkedList n, int j, int size){
        if(j==size-1){
            return;
        }
        
        SinglyNode minNode = findMinNode(n, j, size);
        int temp = n.nodeAt(j).element;
        n.nodeAt(j).element = minNode.element;
        minNode.element = temp;
        
        selSortList(n, j+1, size);
    }
    
    public static void insertionSortList(DoublyList h, int size){
        if(size<=1){
            return;
        }
        
        insertionSortList(h, size-1);
        int key = h.nodeAt(size-1).element;
        int j = size-2;
        
        while(j>=0 && key<h.nodeAt(j).element){
            h.nodeAt(j+1).element = h.nodeAt(j).element;
            j--;
        }
        
        h.nodeAt(j+1).element=key;
    }
    
    public static boolean binarySearch(int[]a , int elem, int l, int r){
        if(l<=r){
            int mid = (l+r)/2;
            
            if(a[mid]==elem){
                return true;
            }
            
            if(elem<a[mid]){
                return binarySearch(a, elem, l, mid-1);
            }
            
            else{
                return binarySearch(a, elem, mid+1, r);
            }
        }
        
        return false;
    }
    
     public static int fibonacci(int i){
        if(i<=2){
            return 1;
        }
        
        return fibonacci(i-1) + fibonacci (i-2);
    }

    
     
     
     
    public static void main (String[] args){
        
        int[] a = {90,80,70,60,50};
        selSortArray(a, 0);
        System.out.println("\n/////// Selection Sort Using Array ///////");
        for(int i=0; i<a.length; i++){
            System.out.print(a[i] + " ");
        }
        System.out.println();
        
        int[] b = {900,800,700,600,500};
        insertionSortArray(b, b.length);
        System.out.println("\n/////// Insertion Sort Using Array ///////");
        for(int i=0; i<b.length; i++){
            System.out.print(b[i] + " ");
        }
        
        int[] c = {80,20,10,100,90};
        LinkedList c1 = new LinkedList(c);
        int c2 = c1.countSinglyNode();
        bubbleSortList(c1, 0, c2);
        System.out.println("\n/////// Bubble Sort Using Singly Linked List ///////");
        c1.printList();
        
        int[] d = {3, 2, 5, 1, 0};
        LinkedList d1 = new LinkedList(d);
        int d2 = d1.countSinglyNode();
        selSortList(d1, 0, d2);
        System.out.println("\n/////// Selection Sort Using Singly Linked List ///////");
        d1.printList();
        
        int[] e = {1, 8, 2, 5, 3, 6};
        DoublyList e1 = new DoublyList(e);
        int e2 = e1.countDoublyNode();
        insertionSortList(e1, e2);
        System.out.println("\n/////// Insertion Sort Using Doubly Linked List ///////");
        e1.forwardprint();
        
        System.out.println();
        System.out.println("\n/////// Binary Search Using Array ///////");
        System.out.println(binarySearch(e, 2, 0, e.length-1));
        System.out.println(binarySearch(e, 10, 0, e.length-1));
        
        System.out.println("\n/////// n-th Fibonacci ///////");
        System.out.println(fibonacci(6));
    }
}
        