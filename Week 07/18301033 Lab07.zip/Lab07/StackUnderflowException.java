package lab07;

public class StackUnderflowException extends Exception{

}