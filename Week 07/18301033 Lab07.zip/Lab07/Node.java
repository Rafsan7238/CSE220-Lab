package lab07;

public class Node{
    Object val;
    Node next;
    
    public Node(Object v, Node n){
        val = v;
        next = n;
    }
}