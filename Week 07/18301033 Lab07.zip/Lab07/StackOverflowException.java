package lab07;

public class StackOverflowException extends Exception{


}